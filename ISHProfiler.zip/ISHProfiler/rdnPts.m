function pos=rdnPts(x0,y0,R,n)
% RDNPTS Gets random postions in a defined area
% 
% Qing Zhong, USZ/UZH, qing.zhong@usz.ch, 03.02,2015

t = 2*pi*rand(n,1);
r = R*sqrt(rand(n,1));
x = x0 + r.*cos(t);
y = y0 + r.*sin(t);
pos.x = x;
pos.y = y;